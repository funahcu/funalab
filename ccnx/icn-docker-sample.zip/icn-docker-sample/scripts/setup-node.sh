#!/bin/bash

# ノードセットアップスクリプト

NODE_ID=${NODE_ID:-1}
NEIGHBOR_IP=${NEIGHBOR_IP:-cefore-node2}
CONFIG_DIR="/usr/local/cefore/"
LOG_DIR="/var/log/cefore"

echo "Setting up Cefore Node ${NODE_ID}..."

# 設定ディレクトリとログディレクトリの作成
mkdir -p ${CONFIG_DIR}
mkdir -p ${LOG_DIR}

# cefnetd設定ファイルの生成
cat > ${CONFIG_DIR}/cefnetd.conf << EOF
# Cefore Node ${NODE_ID} Configuration

# Node Information
NODE_NAME=cefore-node${NODE_ID}

# Network Configuration
PORT=9896
LOG_LEVEL=2

# Buffer Sizes
FIB_SIZE=1000
PIT_SIZE=1000
CS_SIZE=1000

CS_MODE=1

# Transport
TRANSPORT=udp

# Faces (隣接ノードへの接続)
# この設定は動的に追加される

# Cache Configuration
CACHE_TYPE=fifo
CACHE_DEFAULT_RCT=300000

# Security
ENABLE_CCNINFO=yes

# Logging
LOG_FILE=${LOG_DIR}/cefnetd.log
EOF

# csmgrd設定ファイルの生成（Content Store Manager用）
cat > ${CONFIG_DIR}/csmgrd.conf << EOF
# Content Store Manager Configuration for Node ${NODE_ID}

# Cache Settings
CACHE_CAPACITY=10000
CACHE_CHUNK_MAX=1000

# Storage
STORAGE_PATH=/var/cache/cefore/node${NODE_ID}
STORAGE_SIZE=1000000

# Logging
LOG_LEVEL=2
LOG_FILE=${LOG_DIR}/csmgrd.log

# Port
PORT=9799
EOF

# キャッシュディレクトリの作成
mkdir -p /var/cache/cefore/node${NODE_ID}

echo "Node ${NODE_ID} setup completed."
echo "Configuration files created in ${CONFIG_DIR}"
echo "Log directory: ${LOG_DIR}"
