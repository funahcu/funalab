#!/bin/bash

# Cefore起動スクリプト

set -e

# 環境変数の確実な設定
export USER=${USER:-cefore}
export HOME=${HOME:-/home/cefore}
export NODE_ID=${NODE_ID:-1}
export NEIGHBOR_IP=${NEIGHBOR_IP:-cefore-node2}

echo "Starting Cefore Node ${NODE_ID} as user: ${USER}..."

# ノードセットアップの実行
sudo /usr/local/bin/setup-node.sh

# 権限の確認と修正
sudo chown -R ${USER}:${USER} /usr/local/cefore /var/log/cefore /var/run/cefore 2>/dev/null || true

# 隣接ノードが利用可能になるまで待機
echo "Waiting for neighbor node ${NEIGHBOR_IP}..."
while ! ping -c1 ${NEIGHBOR_IP} &>/dev/null; do
    echo "Waiting for ${NEIGHBOR_IP} to be available..."
    sleep 2
done

echo "${NEIGHBOR_IP} is available!"

# cefnetdを起動
echo "Starting cefnetd as user ${USER}..."
if ! cefnetdstart; then
    echo "Error invoking cefnetdstart"
    if ls /tmp/cef_* 1> /dev/null 2>&1; then
        echo "/tmp/cef_* files found"
        rm -f /tmp/cef_*
    else
        echo "No /tmp/cef_* files"
    fi
    echo "Retrying cefnetdstart..."
    cefnetdstart
else
    echo "Succeeded to start cefnetd"
fi

# cefnetdが起動するまで待機
sleep 3

# 隣接ノードへのFaceを追加
#echo "Adding face to neighbor ${NEIGHBOR_IP}..."
#cefroute add ccnx:/ udp ${NEIGHBOR_IP} 9896

# csmgrdを起動（Content Store Manager）
#echo "Starting csmgrd..."
#csmgrdstart

# ノードの状態を表示
echo "Cefore Node ${NODE_ID} Status:"
cefstatus

echo "Cefore Node ${NODE_ID} is ready!"
